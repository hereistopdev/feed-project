import "./App.css";
import FeedFetcher from "./components/FeedFetcher";

function App() {
  return (
    <div className="App">
      <FeedFetcher />
    </div>
  );
}

export default App;
